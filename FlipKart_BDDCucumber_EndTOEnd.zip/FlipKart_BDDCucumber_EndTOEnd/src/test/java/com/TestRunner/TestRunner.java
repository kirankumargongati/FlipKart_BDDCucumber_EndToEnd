package com.TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(features ="src/test/java/Features",glue= {"com/StepDefinition","com.Hooks"},monochrome=true,tags="@tc006",
                      plugin= {"pretty","html:target/cucumber.html"})
//plugin= {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}  
//plugin= {"pretty","json:target/cucumber.json"}


public class TestRunner extends AbstractTestNGCucumberTests{

}

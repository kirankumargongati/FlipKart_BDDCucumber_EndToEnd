package com.Hooks;

import java.io.IOException;

import com.BaseClass.Library;

import ReusableFunctions.SeleniumReusable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class hooks extends Library {
	Scenario scenario;
	SeleniumReusable se;
  @Before
  public void test(Scenario cucumberScenario) throws IOException {
	  scenario=cucumberScenario;
	  launchapplication();
  }
  @After
  public void appclose(Scenario scenario) {
	  se=new SeleniumReusable(driver);
	  se.attachscreenshot(scenario);
	 se.closebrowser();
  }
  
}

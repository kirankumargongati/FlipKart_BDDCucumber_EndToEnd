package com.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseClass.Library;

import ReusableFunctions.SeleniumReusable;

public class Fashion_page extends Library {
	SeleniumReusable se;
public Fashion_page(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
	se=new SeleniumReusable(driver);
}
@FindBy(xpath="//span[text()=\"Fashion\"]")
WebElement fashionlink;
@FindBy(xpath="//a[text()='Kids']")
WebElement kindslink;
@FindBy(xpath="//a[text()='Girls Dresses']")
WebElement Girlsdresslink;
@FindBy(xpath="//div[text()=\"Price -- Low to High\"]")
WebElement priceLowtoHigh;

public void movefashionlink() {
	
	se.mouseHover(fashionlink);
}
public void movekidslink() {
	se.mouseHover(kindslink);
}
public void clickgirlslink() {
	se.moveToElement(Girlsdresslink);
}
public void clickprice() {
	se.click(priceLowtoHigh);
}


}

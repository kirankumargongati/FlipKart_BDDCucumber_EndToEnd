package com.Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseClass.Library;

import ReusableFunctions.SeleniumReusable;

public class Titleprice_page extends Library {
	public SeleniumReusable se;
	
public Titleprice_page(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver,this);
	 se=new SeleniumReusable(driver);
}
@FindBy(name="q")
WebElement Search;
@FindBy(xpath="//button[@type=\"submit\"]")
WebElement searchIcon;
@FindBy(xpath="//div[@class=\"nZIRY7\"]/ div/div/div")
List<WebElement> multipleshirtlinks;

public void entersearch(String Text) {
	se.Entervalue(Search, Text);
}
public void clickserachicon() {
	se.click(searchIcon);
}
public void multipleText() {
	se.MultipleGetText(multipleshirtlinks);
}




}

package com.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseClass.Library;

import ReusableFunctions.SeleniumReusable;

public class Filter_Page extends Library {
public	SeleniumReusable se;
public Filter_Page(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
	se=new SeleniumReusable(driver);
	   
}
@FindBy(xpath="//div[@class=\"FrhiFV\"]/select")
WebElement MiniumumAmount;
@FindBy(xpath="//div[contains(@class,\"WoG\")]/select")
WebElement MaximumAmount;
@FindBy(xpath="//div[text()=\"OPPO\"]/preceding-sibling :: div")
WebElement Brand;
@FindBy(xpath="//div[text()=\"3 GB\"]/preceding-sibling :: div")
WebElement Ram;
@FindBy(xpath="//div[text()=\"Battery Capacity\"]/parent :: div")
WebElement Batteryarrow;
@FindBy(xpath="//div[text()=\"4000 - 4999 mAh\"]/preceding-sibling:: div")
WebElement BatteryCapacity;
public void Min() throws InterruptedException {
	se.explicitlywait(MiniumumAmount);
    se.dropdown(MiniumumAmount, "₹10000");
    
}
public void Max() {
	se.explicitlywait(MaximumAmount);
    se.dropdown(MaximumAmount, "₹20000");
}
public void brand() throws InterruptedException {
	//se.explicitlywait(Brand);
	se.click(Brand);
}
public void ram() {
	se.Scrolldown(Ram);
	se.click(Ram);
}
public void Battery() {
	se.Scrolldown(Batteryarrow);
	se.click(Batteryarrow);
	se.explicitlywait(BatteryCapacity);
	se.click(BatteryCapacity);
}

}

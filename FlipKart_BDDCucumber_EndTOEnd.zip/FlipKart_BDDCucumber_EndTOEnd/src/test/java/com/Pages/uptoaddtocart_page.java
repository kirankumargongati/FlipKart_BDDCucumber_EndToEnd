package com.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseClass.Library;

import ReusableFunctions.SeleniumReusable;

public class uptoaddtocart_page extends Library {
	public SeleniumReusable se;
public uptoaddtocart_page(WebDriver driver) {
	this.driver=driver;
	PageFactory.initElements(driver, this);
	 se=new SeleniumReusable(driver);
}
@FindBy(linkText ="Login")
WebElement logiginlink;
@FindBy(xpath="//li[text()='Flipkart Plus Zone']")
WebElement FlipkarplusZone;
@FindBy(xpath="//span[text()='Home & Furniture']")
WebElement HomeFurniturelink;
@FindBy(linkText="Wall Lamp")
WebElement Walllamplink;
@FindBy(xpath="//div[@data-id=\"WLMGD7JRYTTEBMHM\"]/div")
WebElement clickonelamp;
@FindBy(xpath="//input[@id=\"pincodeInputId\"]")
WebElement Pincode;
@FindBy(xpath="//span[text()=\"Check\"]")
WebElement  checklink;
public void moveloginlink() {
	se.mouseHover(logiginlink);
}
public void Moveflipkarplus() {
	se.moveToElement(FlipkarplusZone);
}
public void movehomefurniture() {
	se.mouseHover(HomeFurniturelink);
}
public void clickwalllamp() {
	se.moveToElement(Walllamplink);
}
public void clickoneresult() {
	se.explicitlywait(clickonelamp);
	se.Scrolldown(clickonelamp);
}
public void enterpincode() throws InterruptedException {
	se.windowhandling(clickonelamp);
	//se.explicitlywait(Pincode);
	se.staleElemnt(Pincode, "560005");
	//Pincode.sendKeys("560005");
}
public void clickchecklink() {
	se.click(checklink);
}



}

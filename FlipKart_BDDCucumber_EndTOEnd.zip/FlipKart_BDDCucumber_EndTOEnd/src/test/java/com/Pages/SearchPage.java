package com.Pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseClass.Library;
import com.Utilities.ExcelUtility;

import ReusableFunctions.SeleniumReusable;

public class SearchPage extends Library {
	public  SeleniumReusable se;

	public SearchPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		se=new SeleniumReusable(driver);
	}
	@FindBy(xpath="//input[@name=\"q\"]")
	WebElement Searchtext;
	@FindBy(xpath="//html[@lang=\"en-IN\"]")
	WebElement HomePage;
	@FindBy(xpath="//html[@lang=\"en\"]")
	WebElement SearchResult;
	@FindBy(xpath="//button[contains(@class,\"dSM5Ub l_\")]")
	WebElement popup;
	@FindBy(xpath="//div[contains(@data-id,\"MOB\")]//a/div[2]/div[1]")
	List<WebElement> Entireresults;
	@FindBy(xpath="//div[@id=\"container\"]/div/div[3]/div/div[2]/div[4]")
	WebElement thirdresult;
	public void pophandle() {
		se.click(popup);
	}
	public void Search(String text) {
		se.Entervalue(Searchtext, text);
	}
	public void ClickSearch() {
		Searchtext.sendKeys(Keys.ENTER);
	}
	public void HomeScreen() {
		System.out.println(HomePage.isDisplayed());
	}
	public void Result() {
		System.out.println(SearchResult.isDisplayed());
		System.out.println(driver.getTitle());
	}
	public void printentireresult() {
		se.MultipleGetText(Entireresults);
	}
	public void print3rdresult() {
		se.Getvalue(thirdresult);
	}
	public void searchWithExcel() throws IOException, InterruptedException {
		ExcelUtility excel=new ExcelUtility();
		for(int i=1;i<=6;i++) {
			se.Entervalue(Searchtext, excel.Excelread("TestData", i, 0));
			Searchtext.sendKeys(Keys.ENTER);
			se.waits();
			se.navigate();
		}
	}


}

package com.Pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseClass.Library;

import ReusableFunctions.SeleniumReusable;

public class MultipleSearch extends Library {
	public  SeleniumReusable se;
 public MultipleSearch(WebDriver driver) {
	 this.driver=driver;
	 PageFactory.initElements(driver, this);
	  se=new SeleniumReusable(driver);
 }
 
 @FindBy(xpath="//input[@name=\"q\"]")
	WebElement Searchfield;
 
 public void Entertext( String SearchText) {
	se.Entervalue(Searchfield, SearchText);
	 
 }
 public void clicksearch() {
	 Searchfield.sendKeys(Keys.ENTER);
 }
 
 
 
 
}

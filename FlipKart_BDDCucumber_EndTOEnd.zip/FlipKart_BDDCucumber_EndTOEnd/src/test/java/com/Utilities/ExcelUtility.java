package com.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {
	public String Excelread(String sheetName,int RowNumber,int CellNumber) throws IOException {
		File path=new File("TestData/FlipkartTestData.xlsx");
		FileInputStream file=new FileInputStream(path);
		XSSFWorkbook workbook=new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheet(sheetName);
		//int rowcount=sheet.getLastRowNum();
		XSSFRow row=sheet.getRow(RowNumber);
		XSSFCell c=row.getCell(CellNumber);
		return c.getStringCellValue();
		
	}

}

package com.StepDefinition;

import org.openqa.selenium.By;

import com.BaseClass.Library;
import com.Pages.Filter_Page;

import ReusableFunctions.SeleniumReusable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class Filter_StepDefinition extends Library {
	public Filter_Page fp;
   public  SeleniumReusable se;
	@Then("Select Maximum and Minimum Amount")
	public void select_maximum_and_minimum_amount() throws InterruptedException {
	     fp=new Filter_Page(driver);
	     System.out.println("*************************************************");
	    String BeforeFilter=driver.findElement(By.xpath("//div[@id=\"container\"]/div/div[3]/div/div[2]/div[2]")).getText();
	    System.out.println("BEFORE FILTER"+BeforeFilter);
	   
	     fp.Min();
	      se=new SeleniumReusable(driver);
	     se.waits();
	     fp.Max();
	     se.waits();
	}

	@Then("Select the Brand")
	public void select_the_brand() throws InterruptedException {
	    fp.brand();
	    se.waits();
	}

	@Then("Select the Ram")
	public void select_the_ram() throws InterruptedException {
	   fp.ram();
	   se.waits();
	}

	@Then("Select the Battery capacity")
	public void select_the_battery_capacity() throws InterruptedException {
	    fp.Battery();
	    se.waits();
	}

	@Then("it should display the relavent result")
	public void it_should_display_the_relavent_result() {
		System.out.println("*************************************************");
		   String AfterFilter=driver.findElement(By.xpath("//div[@id=\"container\"]/div/div[3]/div/div[2]/div[2]")).getText();
		   System.out.println("AFTER FILETER"+AfterFilter);
	}

}

package com.StepDefinition;

import java.io.IOException;

import com.BaseClass.Library;
import com.Pages.SearchPage;

import ReusableFunctions.SeleniumReusable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchWithExcel_StepDefinition extends  Library {
	public SeleniumReusable re;
	public SearchPage se;
	@Given("Enter Search Text in the search field")
	public void enter_search_text_in_the_search_field() throws IOException, InterruptedException {
		  se=new SearchPage(driver);
		  se.searchWithExcel();
	}

	@When("Click search Icon")
	public void click_search_icon() {
		 re=new SeleniumReusable(driver);
	    re.screenshot("searchimg");
	}

	@Then("It should display the relevent result")
	public void it_should_display_the_relevent_result() {
	    re.getTitle();
	}
}

package com.StepDefinition;

import java.io.IOException;

import com.BaseClass.Library;
import com.Pages.SearchPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchMobile_TestCase extends Library{
	public  SearchPage sp;
	@Given("Launch the flipkart Application")
	public void launch_the_flipkart_application() throws IOException {
		//launchapplication();
		System.out.println("Browser launched successfully");
	}

	@When("close the popup")
	public void close_the_popup() {
		sp=new SearchPage(driver);
		sp.pophandle();
	   System.out.println( driver.getTitle());
	}

	@Then("It should navigate to the home page")
	public void it_should_navigate_to_the_home_page() {
		 
		 sp.HomeScreen();
		 
	}

	@Given("User enter the text in the text field")
	public void user_enter_the_text_in_the_text_field() {
		sp.Search("Mobile");
	    
	}

	@When("Click on the searchButton")
	public void click_on_the_search_button() {
	   sp.ClickSearch();
	}

	@Then("It should Navigate to the searchResult page and display the relevant Details")
	public void it_should_navigate_to_the_search_result_page_and_display_the_relevant_details() {
	    sp.Result();
	}
	@Then("Extract the result and print in console")
	public void extract_the_result_and_print_in_console() {
	   sp.printentireresult();
	   System.out.println("****************************************************************");
	}

	@Then("print the third result and keep it in console")
	public void print_the_third_result_and_keep_it_in_console() {
	    sp.print3rdresult();
	}

}

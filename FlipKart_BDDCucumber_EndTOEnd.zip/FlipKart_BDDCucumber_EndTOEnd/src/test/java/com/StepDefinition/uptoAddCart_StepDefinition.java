package com.StepDefinition;

import com.BaseClass.Library;
import com.Pages.uptoaddtocart_page;

import ReusableFunctions.SeleniumReusable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class uptoAddCart_StepDefinition extends Library {
	public   uptoaddtocart_page up;
	  public SeleniumReusable re;
	@Given("User can move to the login link")
	public void user_can_move_to_the_login_link() {
	     up=new uptoaddtocart_page(driver);
	     up.moveloginlink();
	     System.out.println("parent Title");
	     re=new SeleniumReusable(driver);
	     re.getTitle();
	}

	@When("User can click the flipkart plus zone")
	public void user_can_click_the_flipkart_plus_zone() {
	   up.Moveflipkarplus();
	}
	@When("Mouse move to the Home&Furniture link")
	public void mouse_move_to_the_home_furniture_link() {
	    up.movehomefurniture();
	}


	@When("Going to click the wall lamp")
	public void going_to_click_the_wall_lamp() {
	    up.clickwalllamp();
	}

	@When("Scroll down the page and click one particular result")
	public void scroll_down_the_page_and_click_one_particular_result() {
	    up.clickoneresult();
	}

	@When("Enter delivery pincode and click the check link")
	public void enter_delivery_pincode_and_click_the_check_link() throws InterruptedException {
	up.enterpincode();
	}

	@Then("Pincode should be checked and displayed and verify the titeles")
	public void pincode_should_be_checked_and_displayed_and_verify_the_titeles() {
	    up.clickchecklink();
	    System.out.println("childwindow title");
	     re.getTitle();
	     re.Screenshot();
	}

}

package com.StepDefinition;

import com.BaseClass.Library;
import com.Pages.MultipleSearch;

import ReusableFunctions.SeleniumReusable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MultipleSearch_StepDefinition extends Library {
	public MultipleSearch ms;
	public SeleniumReusable se;
	@Given("Enter the {string} in the search field")
	public void enter_the_in_the_search_field(String SearchText) {
	     ms=new MultipleSearch(driver);
	     ms.Entertext(SearchText);
	}

	@When("click the search button")
	public void click_the_search_button() {
	    ms.clicksearch();
	}

	@Then("It should navigate to the next page and display the corresponding page")
	public void it_should_navigate_to_the_next_page_and_display_the_corresponding_page() {
	     se=new SeleniumReusable(driver);
	     se.getTitle();
	     System.out.println("*************************************");
	    se.Screenshot();
	}
}

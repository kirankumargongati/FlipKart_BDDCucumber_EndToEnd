package com.StepDefinition;

import com.BaseClass.Library;
import com.Pages.Fashion_page;

import ReusableFunctions.SeleniumReusable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Fashion_StepDefinition extends Library{
	public   Fashion_page fp;
	public SeleniumReusable se;
	@Given("User to move the Fashion link")
	public void user_to_move_the_fashion_link() {
	   fp=new Fashion_page(driver);
	    se= new SeleniumReusable(driver);
	    System.out.println("Before clicking on fashion link");
	    se.getTitle();
	    fp.movefashionlink();
	}

	@When("cursor to move to the kids link")
	public void cursor_to_move_to_the_kids_link() {
	    fp.movekidslink();
	}

	@When("Move to girls dress and click")
	public void move_to_girls_dress_and_click() {
	    fp.clickgirlslink();
	}

	@When("Click the price high to low link")
	public void click_the_price_high_to_low_link() {
	    fp.clickprice();
	}

	@Then("It should display the relevent details and get the title")
	public void it_should_display_the_relevent_details_and_get_the_title() {
	   System.out.println(" After clicking on fashion link");
	   se.getTitle();
	}
}

package com.StepDefinition;

import com.BaseClass.Library;
import com.Pages.Titleprice_page;

import ReusableFunctions.SeleniumReusable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Titleprice_StepDefinition extends Library {
	public Titleprice_page tp;
	public SeleniumReusable se;
	@Given("Enter teh search text in the search field")
	public void enter_teh_search_text_in_the_search_field() {
    tp=new Titleprice_page(driver);
    tp.entersearch("shirt");
	}

	@When("Click the search icon")
	public void click_the_search_icon() {
	    tp.clickserachicon();
	}

	@Then("It should display the search result and get the title and price")
	public void it_should_display_the_search_result_and_get_the_title_and_price() {
	     se=new SeleniumReusable(driver);
	     tp.multipleText();
	}



}

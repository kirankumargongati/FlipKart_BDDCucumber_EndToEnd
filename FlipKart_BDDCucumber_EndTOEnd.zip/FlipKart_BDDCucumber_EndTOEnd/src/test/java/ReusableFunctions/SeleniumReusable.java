package ReusableFunctions;

import java.io.File;
import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.BaseClass.Library;

import io.cucumber.java.Scenario;

public class SeleniumReusable extends Library{
	public Actions act;
public SeleniumReusable(WebDriver driver) {
	this.driver=driver;
}

//Enter a text
public void Entervalue(WebElement element,String Text) {
	try {
		element.sendKeys(Text);
	}catch(Exception e) {
		System.out.println("No Such ElementExection");
	}
}

//Click on WebElement
public void click(WebElement element) {
	try {
		element.click();
	}catch(Exception e) {
		System.out.println("NoSuchElement Exception");
	}
}

//get title of the page
public void getTitle() {
	try {
		System.out.println(driver.getTitle());
	}catch(Exception e) {
		System.out.println("Didn't found title");
	}
}

//Take Screenshot
public void screenshot(String imgName) {
	File Source=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	File Target=new File("screenshots/"+imgName+".jpg");
	try {
		FileUtils.copyFile(Source, Target);
	}catch(Exception e) {
		System.out.println("Screenshot not found");
	}
}
public void MultipleGetText(List<WebElement> element) {
	List<WebElement> text=element;
	System.out.println(text.size());
	for(WebElement textcount:text) {
		String totallist=textcount.getText();
		System.out.println("****************************");
		System.out.println(totallist);
	}
}
public void Getvalue(WebElement element) {
	String Text=element.getText();
	System.out.println(Text);
}
public void dropdown(WebElement element, String Text) {
	Select drop=new Select(element);
	drop.selectByVisibleText(Text);
}
public void Scrolldown(WebElement element) {
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("arguments[0].click()", element);
	
}
public void waits() throws InterruptedException {
	Thread.sleep(200);
}
public void mouseHover(WebElement element) {
	 act=new Actions(driver);
	act.moveToElement(element).build().perform();
}
public void moveToElement(WebElement element) {
	act.moveToElement(element).click().build().perform();
}
public void explicitlywait(WebElement element) {
	WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(200));
	wait.until(ExpectedConditions.visibilityOf(element));
}
public void Screenshot() {
	File source=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	File target=new File("screenshots/img.jpg");
	try {
		FileUtils.copyFile(source, target);
	}catch(Exception e) {
		System.out.println("coundn't take screenshot");
	}
}
public void windowhandling(WebElement element) {
	String parentwindow=driver.getWindowHandle();
	element.click();
	System.out.println(parentwindow);
	Set<String>  allwindow=driver.getWindowHandles();
	System.out.println("size of windows: "+allwindow.size());
	for(String Childwindow: allwindow) {
		driver.switchTo().window(Childwindow);
		System.out.println("child window: "+Childwindow);
	}
}
public void staleElemnt(WebElement element,String text) {
	try {
	element.sendKeys(text);
	}catch(Exception e) {
		System.out.println("retry");
	}
	element.sendKeys(text);
}
public void attachscreenshot(Scenario scenario) {
	String ScenarionName=scenario.getName().replaceAll(" ", "_");
	final byte[] screenshot=((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	scenario.attach(screenshot, "image/png", ScenarionName);
	
}
public void closebrowser() {
	driver.quit();
}
public void navigate() {
	driver.navigate().back();
}

}
